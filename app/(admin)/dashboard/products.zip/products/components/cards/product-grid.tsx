"use client"

import type { ProductWithDetails } from "../../types/product"

import { ProductCard } from "./product-card"

interface ProductGridProps {
  products: ProductWithDetails[]

  onEdit: (product: ProductWithDetails) => void

  onArchive: (product: ProductWithDetails) => void
}

export function ProductGrid({
  products,
  onEdit,
  onArchive,
}: ProductGridProps) {
  if (products.length === 0) {
    return (
      <div className="rounded-lg border p-10 text-center text-muted-foreground">
        No products found.
      </div>
    )
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          onEdit={onEdit}
          onArchive={onArchive}
        />
      ))}
    </div>
  )
}