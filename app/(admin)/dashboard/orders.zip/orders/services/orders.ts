import { createClient } from "@/lib/supabase/client"
import type {
  CreateOrderInput,
  MaterialSnapshot,
  LaborSnapshot,
} from "../types/order"

import type { OrderStatus } from "../types/order"

import { getProductPricingForDimensions } from "../../products/services/product-pricing"

import { createOrderServer } from "../actions/create-order"

const supabase = createClient()

interface ProductPricingSnapshot {
  productId: string
  productName: string

  width: number | null
  height: number | null
  depth: number | null

  materialSubtotal: number
  laborSubtotal: number
  markupAmount: number

  unitPrice: number

  materials: MaterialSnapshot[]
  labor: LaborSnapshot[]
}

async function buildProductPricingSnapshot(
  productId: string,
  dimensions: {
    width?: number | null
    height?: number | null
    depth?: number | null
  }
): Promise<ProductPricingSnapshot> {
  // Load product
  const { data: product, error: productError } = await supabase
    .from("products")
    .select("id, product_name")
    .eq("id", productId)
    .single()

  if (productError || !product) {
    throw new Error("Product not found")
  }

  const pricingResult = await getProductPricingForDimensions(
    productId,
    dimensions
  )

  if (!pricingResult.data) {
    throw new Error(
      pricingResult.error ?? "Failed to calculate product pricing"
    )
  }

  const pricing = pricingResult.data

  const markupAmount =
    pricing.sellingPrice - pricing.materialCost - pricing.laborCost

  return {
    productId: product.id,
    productName: product.product_name,

    width: pricing.width,
    height: pricing.height,
    depth: pricing.depth,

    materialSubtotal: pricing.materialCost,
    laborSubtotal: pricing.laborCost,
    markupAmount,

    unitPrice: pricing.sellingPrice,

    materials: pricing.materialsSnapshot,
    labor: pricing.laborSnapshot,
  }
}

export async function createOrder(input: CreateOrderInput) {
  return await createOrderServer(input)
}

export async function getOrders() {
  const { data, error } = await supabase
    .from("orders")
    .select(
      `
        *,
        profiles (
          id,
          first_name,
          last_name,
          full_name
        ),
        order_items (
          *
        ),order_addresses (
          *
        )
      `
    )
    .order("created_at", { ascending: false })

  if (error) throw error

  return (data ?? []).map((order) => ({
    ...order,
    items: order.order_items ?? [],
    address: Array.isArray(order.order_addresses)
      ? (order.order_addresses[0] ?? null)
      : (order.order_addresses ?? null),
  }))
}
export async function getOrderById(orderId: string) {
  const { data, error } = await supabase
    .from("orders")
    .select(
      `
        *,
        profiles (
          id,
          first_name,
          last_name,
          full_name
        ),
        order_items (
          *
        ),
        order_addresses (
          *
        )
      `
    )
    .eq("id", orderId)
    .single()

  if (error) throw error

  return {
    ...data,
    items: data.order_items ?? [],
    address: Array.isArray(data.order_addresses)
      ? (data.order_addresses[0] ?? null)
      : (data.order_addresses ?? null),
  }
}

// Update order status
export async function updateOrderStatus(
  orderId: string,
  status: OrderStatus,
  options?: {
    assignedTo?: string
    estimatedCompletionDate?: string
  }
) {
  /*
   * Production must only be started through
   * startOrderProduction().
   *
   * That workflow uses the start_order_production RPC,
   * which securely checks the 50% payment requirement
   * and initializes production as "pending".
   */
  if (status === "in_production") {
    throw new Error(
      "Production must be started through the Start Production workflow"
    )
  }

  const updateData: Record<string, any> = {
    status,
    updated_at: new Date().toISOString(),
  }

  /*
   * Keep these optional fields for any existing status-update
   * flows that may still provide production information.
   */
  if (options?.assignedTo) {
    updateData.production_assigned_to = options.assignedTo
  }

  if (options?.estimatedCompletionDate) {
    updateData.estimated_completion_date = options.estimatedCompletionDate
  }

  const { data, error } = await supabase
    .from("orders")
    .update(updateData)
    .eq("id", orderId)
    .select()
    .single()

  if (error) throw error

  return data
}

// Save quotation details
export async function saveOrderQuotation(
  orderId: string,
  quotation: Record<string, any>
) {
  const { data, error } = await supabase
    .from("orders")
    .update({
      quotation,
      status: "quoted",
      updated_at: new Date().toISOString(),
    })
    .eq("id", orderId)
    .select()
    .single()

  if (error) throw error

  return data
}

// Deny an order
export async function denyOrder(orderId: string, reason: string) {
  const trimmedReason = reason.trim()

  if (!trimmedReason) {
    throw new Error("A denial reason is required.")
  }

  const { error } = await supabase.rpc("deny_order", {
    p_order_id: orderId,
    p_reason: trimmedReason,
  })

  if (error) throw error
}

// Approve an order
export async function approveOrder(orderId: string) {
  const { data, error } = await supabase.rpc("approve_order", {
    p_order_id: orderId,
  })

  if (error) throw error

  return data
}

export async function startOrderProduction(
  orderId: string,
  assignedTo: string,
  estimatedCompletionDate: string
) {
  const { error } = await supabase.rpc("start_order_production", {
    p_order_id: orderId,
    p_assigned_to: assignedTo.trim(),
    p_estimated_completion_date: estimatedCompletionDate,
  })

  if (error) {
    throw new Error(error.message || "Failed to start production")
  }
}
