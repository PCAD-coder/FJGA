"use client"
import { useState } from "react"
import { CustomOrderWizard } from "./request-form/custom-order-wizard"

import {
  ArrowRight,
  Clock3,
  FileText,
  PackageCheck,
  Plus,
  Search,
} from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

type CustomOrderStatus =
  | "pending_review"
  | "quote_ready"
  | "in_production"
  | "completed"

interface CustomOrderRequest {
  id: string
  requestNumber: string
  projectName: string
  category: string
  quantity: number
  submittedAt: string
  status: CustomOrderStatus
  image: string
  quoteAmount?: number
}

const mockRequests: CustomOrderRequest[] = [
  {
    id: "1",
    requestNumber: "CO-2026-00128",
    projectName: "Living Room Sliding Window",
    category: "Window",
    quantity: 2,
    submittedAt: "October 8, 2026",
    status: "pending_review",
    image: "/products/sliding-window.jpg",
  },
  {
    id: "2",
    requestNumber: "CO-2026-00121",
    projectName: "Aluminum Glass Door",
    category: "Door",
    quantity: 1,
    submittedAt: "October 3, 2026",
    status: "quote_ready",
    image: "/products/swing-door.jpg",
    quoteAmount: 28500,
  },
  {
    id: "3",
    requestNumber: "CO-2026-00115",
    projectName: "Stair Railing",
    category: "Railing",
    quantity: 1,
    submittedAt: "September 28, 2026",
    status: "in_production",
    image: "/products/placeholder.jpg",
  },
]

const statusConfig: Record<
  CustomOrderStatus,
  {
    label: string
    className: string
  }
> = {
  pending_review: {
    label: "Pending Review",
    className:
      "border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-50",
  },
  quote_ready: {
    label: "Quote Ready",
    className:
      "border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-50",
  },
  in_production: {
    label: "In Production",
    className:
      "border-violet-200 bg-violet-50 text-violet-700 hover:bg-violet-50",
  },
  completed: {
    label: "Completed",
    className:
      "border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-50",
  },
}

function CustomOrderCard({
  request,
}: {
  request: CustomOrderRequest
}) {
  const status = statusConfig[request.status]

  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-sm">
      <CardContent className="p-0">
        <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
          {/* Reference Image */}
          <div className="h-32 w-full shrink-0 overflow-hidden rounded-lg border bg-muted sm:h-28 sm:w-40">
            <img
              src={request.image}
              alt={request.projectName}
              className="h-full w-full object-cover"
            />
          </div>

          {/* Request Information */}
          <div className="min-w-0 flex-1 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-semibold">
                {request.requestNumber}
              </p>

              <Badge
                variant="outline"
                className={status.className}
              >
                {status.label}
              </Badge>
            </div>

            <div>
              <h3 className="text-lg font-semibold">
                {request.projectName}
              </h3>

              <p className="text-sm text-muted-foreground">
                {request.category}
                <span className="mx-2">•</span>
                Quantity: {request.quantity}
              </p>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock3 className="h-4 w-4" />
              <span>
                Submitted {request.submittedAt}
              </span>
            </div>
          </div>

          {/* Right Action */}
          <div className="flex shrink-0 flex-col items-start gap-3 sm:items-end">
            {request.quoteAmount && (
              <p className="text-lg font-bold">
                ₱
                {request.quoteAmount.toLocaleString(
                  "en-PH",
                  {
                    minimumFractionDigits: 2,
                  }
                )}
              </p>
            )}

            {request.status === "quote_ready" ? (
              <Button>
                View Quotation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button variant="ghost">
                View Details
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function RequestList({
  requests,
}: {
  requests: CustomOrderRequest[]
}) {
  if (requests.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex min-h-[300px] flex-col items-center justify-center px-6 py-12 text-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <FileText className="h-6 w-6 text-muted-foreground" />
          </div>

          <h3 className="text-lg font-semibold">
            No custom requests found
          </h3>

          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            Custom project requests matching this
            status will appear here.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      {requests.map((request) => (
        <CustomOrderCard
          key={request.id}
          request={request}
        />
      ))}
    </div>
  )
}

export default function CustomOrder() {
  const [isCreatingRequest, setIsCreatingRequest] =
    useState(false)

  if (isCreatingRequest) {
    return (
      <CustomOrderWizard
        onCancel={() => setIsCreatingRequest(false)}
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Custom Orders
          </h1>

          <p className="mt-1 text-muted-foreground">
            Create and track your made-to-order
            projects with FJGA.
          </p>
        </div>

        <Button
  size="lg"
  onClick={() => setIsCreatingRequest(true)}
>
  <Plus className="mr-2 h-4 w-4" />
  New Custom Request
</Button>
      </div>

      {/* Small Summary */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
              <FileText className="h-5 w-5" />
            </div>

            <div>
              <p className="text-2xl font-bold">
                {mockRequests.length}
              </p>
              <p className="text-sm text-muted-foreground">
                Total Requests
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
              <Clock3 className="h-5 w-5" />
            </div>

            <div>
              <p className="text-2xl font-bold">
                {
                  mockRequests.filter(
                    (request) =>
                      request.status ===
                      "pending_review"
                  ).length
                }
              </p>
              <p className="text-sm text-muted-foreground">
                Pending Review
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
              <PackageCheck className="h-5 w-5" />
            </div>

            <div>
              <p className="text-2xl font-bold">
                {
                  mockRequests.filter(
                    (request) =>
                      request.status ===
                      "in_production"
                  ).length
                }
              </p>
              <p className="text-sm text-muted-foreground">
                In Production
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Requests */}
      <Tabs
        defaultValue="all"
        className="space-y-4"
      >
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <TabsList className="h-auto flex-wrap justify-start">
            <TabsTrigger value="all">
              All Requests
            </TabsTrigger>

            <TabsTrigger value="pending">
              Pending Review
            </TabsTrigger>

            <TabsTrigger value="quote-ready">
              Quote Ready
            </TabsTrigger>

            <TabsTrigger value="production">
              In Production
            </TabsTrigger>

            <TabsTrigger value="completed">
              Completed
            </TabsTrigger>
          </TabsList>

          <div className="relative w-full lg:w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />

            <Input
              placeholder="Search custom requests..."
              className="pl-9"
            />
          </div>
        </div>

        <TabsContent
          value="all"
          className="mt-0"
        >
          <RequestList requests={mockRequests} />
        </TabsContent>

        <TabsContent
          value="pending"
          className="mt-0"
        >
          <RequestList
            requests={mockRequests.filter(
              (request) =>
                request.status ===
                "pending_review"
            )}
          />
        </TabsContent>

        <TabsContent
          value="quote-ready"
          className="mt-0"
        >
          <RequestList
            requests={mockRequests.filter(
              (request) =>
                request.status ===
                "quote_ready"
            )}
          />
        </TabsContent>

        <TabsContent
          value="production"
          className="mt-0"
        >
          <RequestList
            requests={mockRequests.filter(
              (request) =>
                request.status ===
                "in_production"
            )}
          />
        </TabsContent>

        <TabsContent
          value="completed"
          className="mt-0"
        >
          <RequestList
            requests={mockRequests.filter(
              (request) =>
                request.status ===
                "completed"
            )}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}