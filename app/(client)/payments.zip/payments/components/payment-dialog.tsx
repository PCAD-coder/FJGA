"use client"

import { useState } from "react"

import type { Invoice } from "../types/payment"
import { submitPaymentProof } from "../../my-orders/services/payment-submission-service"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Props {
  invoice: Invoice
  onSubmitted?: () => void
}

export default function PaymentDialog({ invoice, onSubmitted }: Props) {
  const [open, setOpen] = useState(false)

  const [paymentMethod, setPaymentMethod] = useState<
    "gcash" | "card" | "online_banking" | ""
  >("")

  const [amount, setAmount] = useState(invoice.amountDue.toString())

  const [paymentDate, setPaymentDate] = useState(
    new Date().toISOString().split("T")[0]
  )

  const [referenceNumber, setReferenceNumber] = useState("")
  const [proofFile, setProofFile] = useState<File | null>(null)
  const [notes, setNotes] = useState("")

  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function resetForm() {
    setPaymentMethod("")
    setAmount(invoice.amountDue.toString())
    setPaymentDate(new Date().toISOString().split("T")[0])
    setReferenceNumber("")
    setProofFile(null)
    setNotes("")
    setError(null)
  }

  async function handleSubmit() {
    try {
      setSubmitting(true)
      setError(null)

      if (!paymentMethod) {
        throw new Error("Please select a payment method")
      }
      const selectedPaymentMethod = paymentMethod as
  | "gcash"
  | "card"
  | "online_banking"

      const numericAmount = Number(amount)

      if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
        throw new Error("Please enter a valid payment amount")
      }

      if (numericAmount > invoice.amountDue) {
        throw new Error("Payment amount cannot exceed the amount due")
      }

      if (!paymentDate) {
        throw new Error("Please select a payment date")
      }

      if (!referenceNumber.trim()) {
        throw new Error("Reference number is required for electronic payments")
      }

      if (!proofFile) {
        throw new Error("Please upload your proof of payment")
      }

      await submitPaymentProof({
        orderId: invoice.orderId,
        amount: numericAmount,
        paymentMethod: selectedPaymentMethod,
        paymentDate,
        referenceNumber,
        notes: notes.trim() || null,
        proofFile,
      })

      setOpen(false)
      resetForm()

      onSubmitted?.()
    } catch (error) {
      console.error("PAYMENT SUBMISSION ERROR:", error)

      setError(
        error instanceof Error ? error.message : "Failed to submit payment."
      )
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        setOpen(value)

        if (!value) {
          resetForm()
        }
      }}
    >
      <DialogTrigger asChild>
        <Button className="w-full">Pay Now</Button>
      </DialogTrigger>

      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Submit Payment</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Invoice Information */}
          <div className="space-y-2 rounded-lg border p-4">
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Invoice No.</span>

              <span className="font-medium">{invoice.invoiceId}</span>
            </div>

            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Order ID</span>

              <span className="font-medium">{invoice.orderNumber}</span>
            </div>

            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Amount Due</span>

              <span className="font-bold">
                ₱{invoice.amountDue.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-2">
            <Label>Payment Method</Label>

            <Select
              value={paymentMethod}
              onValueChange={(value) =>
                setPaymentMethod(value as "gcash" | "card" | "online_banking")
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>

              <SelectContent>
                <SelectItem value="gcash">GCash</SelectItem>

                <SelectItem value="card">Card</SelectItem>

                <SelectItem value="online_banking">Online Banking</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <Label htmlFor="payment-amount">Payment Amount</Label>

            <Input
              id="payment-amount"
              type="number"
              min="0.01"
              max={invoice.amountDue}
              step="0.01"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
            />

            <p className="text-xs text-muted-foreground">
              Maximum payment: ₱{invoice.amountDue.toLocaleString()}
            </p>
          </div>

          {/* Payment Date */}
          <div className="space-y-2">
            <Label htmlFor="payment-date">Payment Date</Label>

            <Input
              id="payment-date"
              type="date"
              value={paymentDate}
              onChange={(event) => setPaymentDate(event.target.value)}
            />
          </div>

          {/* Reference Number */}
          <div className="space-y-2">
            <Label htmlFor="reference-number">Reference Number</Label>

            <Input
              id="reference-number"
              placeholder="Enter reference number"
              value={referenceNumber}
              onChange={(event) => setReferenceNumber(event.target.value)}
            />
          </div>

          {/* Proof */}
          <div className="space-y-2">
            <Label htmlFor="payment-proof">Upload Proof of Payment</Label>

            <Input
              id="payment-proof"
              type="file"
              accept=".jpg,.jpeg,.png,.webp,.pdf"
              onChange={(event) =>
                setProofFile(event.target.files?.[0] ?? null)
              }
            />

            <p className="text-xs text-muted-foreground">
              JPG, PNG, WEBP, or PDF. Maximum 5 MB.
            </p>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="payment-notes">Remarks (Optional)</Label>

            <Input
              id="payment-notes"
              placeholder="Additional remarks..."
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
            />
          </div>

          {/* Error */}
          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              {error}
            </div>
          )}

          {/* Submit */}
          <Button
            className="w-full"
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? "Submitting Payment..." : "Submit Payment"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
