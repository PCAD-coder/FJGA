"use client"

import { useEffect, useState } from "react"

import PaymentHeader from "./payment-header"
import PaymentSummaryCards from "./payment-summary-cards"
import PaymentMethods from "./payment-methods"
import PaymentHistoryTable from "./payment-history-table"
import PendingInvoices from "./pending-invoices"

import type {
  PaymentSummary,
  Invoice,
  PaymentHistory,
} from "../types/payment"

import { getPaymentPageData } from "../services/payment-service"

export default function Payments() {
  const [summary, setSummary] = useState<PaymentSummary>({
    totalPending: 0,
    paidThisMonth: 0,
    outstandingInvoices: 0,
  })

  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [history, setHistory] = useState<PaymentHistory[]>([])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadPayments() {
      try {
        setLoading(true)
        setError(null)

        const data = await getPaymentPageData()

        setSummary(data.summary)
        setInvoices(data.invoices)
        setHistory(data.history)
      } catch (error) {
        console.error("PAYMENTS LOAD ERROR:", error)

        setError(
          error instanceof Error
            ? error.message
            : "Failed to load payment information."
        )
      } finally {
        setLoading(false)
      }
    }

    loadPayments()
  }, [])

  return (
    <div className="space-y-8">
      <PaymentHeader />

      {loading && (
        <div className="rounded-lg border p-6 text-sm text-muted-foreground">
          Loading payment information...
        </div>
      )}

      {!loading && error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-6 text-sm text-red-700">
          {error}
        </div>
      )}

      {!loading && !error && (
        <>
          <PaymentSummaryCards summary={summary} />

          <PendingInvoices invoices={invoices} />

          <PaymentMethods />

          <PaymentHistoryTable history={history} />
        </>
      )}
    </div>
  )
}