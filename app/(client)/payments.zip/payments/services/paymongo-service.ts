"use server"

interface CreateCheckoutSessionInput {
  orderId: string
  orderNumber: string
  productName: string
  amount: number
  customerEmail?: string | null
}

interface PayMongoCheckoutResponse {
  id: string
  checkoutUrl: string
}

export async function createPayMongoCheckoutSession(
  input: CreateCheckoutSessionInput
): Promise<PayMongoCheckoutResponse> {
  const secretKey = process.env.PAYMONGO_SECRET_KEY

  if (!secretKey) {
    throw new Error("PayMongo secret key is not configured")
  }

  if (!input.orderId) {
    throw new Error("Order ID is required")
  }

  if (!input.orderNumber) {
    throw new Error("Order number is required")
  }

  if (!Number.isFinite(input.amount) || input.amount <= 0) {
    throw new Error("Payment amount must be greater than zero")
  }

  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL

  if (!baseUrl) {
    throw new Error("NEXT_PUBLIC_SITE_URL is not configured")
  }

  const amountInCentavos = Math.round(input.amount * 100)

  const response = await fetch(
    "https://api.paymongo.com/v2/checkout_sessions",
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${secretKey}:`).toString(
          "base64"
        )}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        data: {
          attributes: {
            line_items: [
              {
                name: input.productName,
                amount: amountInCentavos,
                currency: "PHP",
                quantity: 1,
              },
            ],

            payment_method_types: [
              "card",
              "gcash",
              "qrph",
            ],

            success_url: `${baseUrl}/client-dashboard/payments?payment=success&order=${encodeURIComponent(
              input.orderId
            )}`,

            cancel_url: `${baseUrl}/client-dashboard/payments?payment=cancelled&order=${encodeURIComponent(
              input.orderId
            )}`,

            reference_number: input.orderNumber,

            metadata: {
              order_id: input.orderId,
              order_number: input.orderNumber,
            },

            ...(input.customerEmail
              ? {
                  billing: {
                    email: input.customerEmail,
                  },
                }
              : {}),
          },
        },
      }),
    }
  )

  const json = await response.json()

  if (!response.ok) {
    console.error("PAYMONGO CHECKOUT ERROR:", json)

    throw new Error(
      json?.errors?.[0]?.detail ||
        "Failed to create PayMongo checkout session"
    )
  }

  const checkoutUrl =
    json?.data?.attributes?.checkout_url

  if (!checkoutUrl) {
    throw new Error(
      "PayMongo did not return a checkout URL"
    )
  }

  return {
    id: json.data.id,
    checkoutUrl,
  }
}