"use client"

import { useMemo, useState, useEffect } from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

import { getCustomizedPrice } from "../actions/get-customized-price"

interface ProductOrderPageProps {
  product: {
    id: string
    name: string
    description: string
    image: string
    width: number
    height: number
    depth: number
    isCustomizable: boolean
    isDepthCustomizable: boolean
  }
  initialPrice: number
}

export default function ProductOrderPage({
  product,
  initialPrice,
}: ProductOrderPageProps) {
  const [width, setWidth] = useState(product.width)
  const [height, setHeight] = useState(product.height)
  const [depth, setDepth] = useState(product.depth)
  const [quantity, setQuantity] = useState(1)
  const [notes, setNotes] = useState("")

const [estimatedPrice, setEstimatedPrice] = useState(initialPrice)

useEffect(() => {
  const timeout = setTimeout(async () => {
    try {
      const result = await getCustomizedPrice(product.id, {
        width,
        height,
        depth,
      })

      setEstimatedPrice(result.sellingPrice)
    } catch (err) {
      console.error(err)
    }
  }, 300)

  return () => clearTimeout(timeout)
}, [width, height, depth, product.id])

  return (
    <div className="mx-auto max-w-5xl p-8">
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <img
            src={product.image}
            alt={product.name}
            className="w-full rounded-lg border object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">
              {product.name}
            </h1>

            <p className="mt-2 text-muted-foreground">
              {product.description}
            </p>
          </div>

          <div className="rounded-lg border p-4">
            <h2 className="mb-4 font-semibold">
              Customize Dimensions
            </h2>

            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Width (cm)
                </label>
                <Input
                  type="number"
                  value={width}
                  disabled={!product.isCustomizable}
                  onChange={(e) =>
                    setWidth(Number(e.target.value))
                  }
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Height (cm)
                </label>
                <Input
                  type="number"
                  value={height}
                  disabled={!product.isCustomizable}
                  onChange={(e) =>
                    setHeight(Number(e.target.value))
                  }
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Depth (cm)
                </label>
                <Input
                  type="number"
                  value={depth}
                  disabled={!product.isDepthCustomizable}
                  onChange={(e) =>
                    setDepth(Number(e.target.value))
                  }
                />
              </div>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground">
              Estimated Price
            </p>
            <p className="text-3xl font-bold text-primary">
              ₱
              {estimatedPrice.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Final price will be calculated on the server before the order is
              created.
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Quantity
              </label>
              <Input
                type="number"
                min={1}
                value={quantity}
                onChange={(e) =>
                  setQuantity(Number(e.target.value))
                }
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">
                Order Notes
              </label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional instructions..."
              />
            </div>

            <Button className="w-full">
              Place Customized Order
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}